module.exports = {
    mongoURI: 'mongodb+srv://admin:admin@wpl-jftvl.mongodb.net/wpl?retryWrites=true&w=majority',
    secret: 'secret'
};